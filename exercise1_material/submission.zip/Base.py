# Layers/Base.py
import numpy as np
class BaseLayer:
    def __init__(self):
        self.trainable = False
