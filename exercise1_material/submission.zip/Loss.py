
import numpy as np


class CrossEntropyLoss:
    def __init__(self):
        self.output = None

    def forward(self, prediction_tensor, label_tensor):
        epsilon = np.finfo(float).eps

        prediction_tensor = np.clip(prediction_tensor, epsilon, 1 - epsilon)
        self.output = prediction_tensor
        cross_entropy_loss = -np.sum(label_tensor * np.log(prediction_tensor))
        return cross_entropy_loss



    def backward(self, label_tensor):
        if self.output is None:
            raise ValueError("Forward method must be called before backward.")
        # Calculate gradient, noting that output might be very close to 0 or 1
        grad = -(label_tensor / self.output)
        return grad

